

import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;



public class MyProgram
{
   public static void main(String[] args) throws IOException
   {
         ArrayList<String> allSongs = new ArrayList<>();

        // File 1
        Scanner lucy = new Scanner(new File("lucy_bedroque.txt"));
        while (lucy.hasNextLine()) {
            allSongs.add(lucy.nextLine());
        }
        lucy.close();

        // File 2
        Scanner idk = new Scanner(new File("idk.txt"));
        while (idk.hasNextLine()) {
            allSongs.add(idk.nextLine());
        }
        idk.close();

        // File 3 (new one)
        Scanner dillinger = new Scanner(new File("christ_dillinger.txt"));
        while (dillinger.hasNextLine()) {
            allSongs.add(dillinger.nextLine());
        }
        dillinger.close();
        
        Collections.shuffle(allSongs);


       boolean nowPlaying = true;
       
       System.out.println("Now Playing:\n");

        for (String song : allSongs){
            String[] parts = song.split(", ");
            if (nowPlaying){
            

            for (String part : parts) {
                System.out.println(part);
 
            }
            System.out.println("");
            System.out.println("Queue:");
            System.out.println("");
            nowPlaying = false;
            }else{
            System.out.println(parts[0]);
  
   }
  }
 }
}